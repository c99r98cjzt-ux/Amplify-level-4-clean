#!/bin/bash
echo 'Installing Ultra Secure App...'
