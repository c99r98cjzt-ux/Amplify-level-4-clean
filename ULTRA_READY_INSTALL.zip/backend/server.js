// Placeholder backend server
console.log('Backend running');