#!/bin/bash
# Codespaces-only one-command installer for Amplify final sale package
set -e
echo "Codespaces One-Command Installer - unpack and run"
unzip AMPLIFY_FINAL_SALE_PACKAGE.zip -d unpack || true
mv unpack/* . || true
rm -rf unpack || true
cp .env.example .env || true
./scripts/install_and_start.sh
