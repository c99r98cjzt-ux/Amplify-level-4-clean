#!/bin/bash
# Docker deploy script for Amplify production installer
set -e
docker-compose up --build -d
echo "Docker compose started - check containers with: docker ps"
