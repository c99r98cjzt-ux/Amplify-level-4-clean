
APP STORE & GOOGLE PLAY PACKAGING GUIDE (Step-by-step)
1. Prepare the PWA in frontend/ and ensure manifest.webmanifest and icons are correct.
2. Install Capacitor: npm install @capacitor/cli @capacitor/core
3. Initialize Capacitor: npx cap init amplify-app com.example.amplify
4. Add platforms: npx cap add ios && npx cap add android
5. Build web assets: npm run build (or ensure frontend is in /frontend)
6. Copy web assets: npx cap copy
7. iOS: open ios/App/App.xcworkspace in Xcode
   - Set the Bundle ID, Signing & Team, and Provisioning Profile.
   - Update app icons and Launch Screens.
   - Archive (Product > Archive) and upload to App Store Connect.
8. Android: open android/ in Android Studio
   - Set keystore properties and build a signed AAB.
   - Upload to Google Play Console, fill store listing and content ratings.
Important notes:
- Use HTTPS for all endpoints when publishing.
- Include privacy policy URL in App Store / Play Console.
- Screenshots should be high-quality (PNG) and match device dimensions.
