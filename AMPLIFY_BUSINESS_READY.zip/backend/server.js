// Amplify Business-Ready backend (Express)
const express = require('express');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/', express.static(path.join(__dirname, '../frontend')));

let KILL_SWITCH = false;

// toggle kill switch - protected endpoints should check this in production
app.post('/api/kill/toggle', (req, res) => {
  const { action } = req.body;
  if (action === 'on') KILL_SWITCH = true;
  if (action === 'off') KILL_SWITCH = false;
  return res.json({ kill: KILL_SWITCH });
});
app.get('/api/kill', (req, res) => res.json({ kill: KILL_SWITCH }));

// campaign discovery - STUB
app.post('/api/campaign/find', (req, res) => {
  if (KILL_SWITCH) return res.status(423).json({ error: 'kill_switch_on' });
  const { title, url } = req.body || {};
  // WARNING: Replace this stub with authorized API or manual entry in production
  const campaign = {
    id: 'demo-' + Date.now(),
    title: title || 'Help Father Fight For Justice After Wrongful Conviction',
    url: url || 'https://gofund.me/your-campaign',
    goal: 45000,
    raised: 0
  };
  res.json(campaign);
});

// analytics stub - in-memory
const events = [];
app.post('/api/analytics/track', (req,res)=>{ events.push(req.body); res.json({ok:true}); });
app.get('/api/analytics/top',(req,res)=>{ res.json({top: events.slice(-10)}); });

// crypto demo address
app.get('/api/crypto/generate', (req,res)=>{
  const addr = '0x' + Math.random().toString(16).slice(2,22);
  res.json({address: addr, network: 'demo-eth'});
});

app.get('/api/health', (req,res)=> res.json({status:'ok', kill: KILL_SWITCH}));

app.listen(PORT, ()=>console.log('Amplify Business backend running on port ' + PORT));
