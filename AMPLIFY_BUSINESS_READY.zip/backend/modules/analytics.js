// backend/modules/analytics.js - simple in-memory event collector
const events = [];
function track(e){ events.push({...e, ts: Date.now()}); }
function recent(n=10){ return events.slice(-n).reverse(); }
module.exports = { track, recent };
