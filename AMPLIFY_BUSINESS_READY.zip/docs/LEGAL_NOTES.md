LEGAL & COMPLIANCE NOTES (summary)
- Fundraising: Confirm compliance with Ohio state law and federal regulations regarding charitable solicitations if you solicit donations widely.
- Payment processors: Use established processors; do not store card data unless PCI-compliant.
- Privacy: Follow GDPR/CCPA where applicable for donor data.
- Terms of Service: Never automate posts on third-party platforms outside their API and terms.
- KYC/AML: For large donations or crypto routing, implement KYC/AML checks.
- Consult an attorney before launching public fundraising campaigns.
