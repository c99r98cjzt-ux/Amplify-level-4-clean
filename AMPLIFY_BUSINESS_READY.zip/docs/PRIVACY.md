PRIVACY POLICY (placeholder)
This app collects minimal personal information needed to process campaign inquiries and send updates to donors. In production, list exactly what you collect, how it is stored, third parties, retention, and user rights. Replace this with a full privacy policy reviewed by counsel.
