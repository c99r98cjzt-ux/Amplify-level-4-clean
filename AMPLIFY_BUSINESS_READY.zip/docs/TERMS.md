TERMS OF SERVICE (placeholder)
This app provides tools to manage and promote fundraising campaigns. You must comply with all applicable laws and platform terms. You agree not to use the app to spam or to post without authorization. Replace with full terms before launch.
