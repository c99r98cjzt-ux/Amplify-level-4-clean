UPLOAD & RUN (iPhone step-by-step)
1) Create a fresh GitHub repo (recommended: amplify-level4-business)
2) Add file -> Upload files -> choose this ZIP -> Commit changes
3) Open Codespace (Code -> Codespaces -> New codespace on main)
4) In Codespaces Terminal:
   mv installer/ultra_installer.txt installer/ultra_installer.sh
   chmod +x installer/ultra_installer.sh
   bash installer/ultra_installer.sh
   ./scripts/codespace_runner.sh
5) Open Ports -> make 3000 public -> Open in Browser
6) Replace stubs with production integrations (API keys, WebAuthn, DB)
