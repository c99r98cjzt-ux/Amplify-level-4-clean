UPLOAD & RUN (Quick)
1) Create new repo: amplify-level4-core
2) Upload this ZIP as release asset or via Add file -> Upload files
3) Open Codespace for repo
4) Run:
   unzip AMPLIFY_LEVEL4_ALLIN.zip -d unpack || true
   mv unpack/* . || true
   mv installer/ultra_installer.txt installer/ultra_installer.sh || true
   chmod +x installer/ultra_installer.sh || true
   bash installer/ultra_installer.sh
   ./scripts/codespace_runner.sh
5) Open Ports tab -> make 3000 public -> Open in Browser
