async function postJson(url, body){ const r=await fetch(url,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)}); return r.json(); }
document.getElementById('find').onclick = async ()=>{ const title = document.getElementById('title').value; const j = await postJson('/api/campaign/find',{title}); document.getElementById('campaign').innerText = JSON.stringify(j,null,2); };
document.getElementById('killOn').onclick = async ()=>{ const r = await postJson('/api/kill/toggle',{action:'on'}); document.getElementById('control').innerText = JSON.stringify(r,null,2); };
document.getElementById('killOff').onclick = async ()=>{ const r = await postJson('/api/kill/toggle',{action:'off'}); document.getElementById('control').innerText = JSON.stringify(r,null,2); };
document.getElementById('gen').onclick = async ()=>{ const r=await fetch('/api/crypto/generate'); document.getElementById('control').innerText = JSON.stringify(await r.json(),null,2); };
