#!/bin/bash
# Codespace runner: installs deps and launches backend in background
set -e
echo "Codespace runner starting..."
[ -f package.json ] || npm init -y >/dev/null 2>&1 || true
npm install express >/dev/null 2>&1 || true
node backend/server.js &
sleep 1
echo "Codespace runner finished. Server should be running on port 3000."
