AMPLIFY LEVEL-4 ALL-INTEGRATION PACKAGE
Repository: amplify-level4-core (recommended)
Purpose: Codespace runner + PWA UI shell + integrated installer + CI workflow & docs

Contents:
- installer/ultra_installer.txt  (rename to .sh in Codespaces and run)
- backend/ (server + modules)
- frontend/ (enhanced PWA shell, passkey/login stub, kill-switch dashboard)
- workflows/ci.yml (GitHub Actions health check)
- scripts/codespace_runner.sh (one-command runner for Codespaces)
- docs/UPLOAD_AND_RUN.md (step-by-step)

Important: After uploading, open Codespace, run the codespace_runner.sh script to install deps and start the server.
