// Amplify Level-4 backend - integrated server
const express = require('express');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/', express.static(path.join(__dirname, '../frontend')));

let KILL_SWITCH = false;

app.post('/api/kill/toggle', (req,res)=>{
  const { action } = req.body;
  if(action==='on') KILL_SWITCH=true;
  if(action==='off') KILL_SWITCH=false;
  return res.json({ kill: KILL_SWITCH });
});

app.post('/api/campaign/find', (req,res)=>{
  const { title, url } = req.body || {};
  return res.json({ id:'demo-'+Date.now(), title: title||'Help Father Fight For Justice After Wrongful Conviction', url: url||'https://gofund.me/your-campaign', goal:45000, raised:0 });
});

app.get('/api/health', (req,res)=> res.json({ status:'ok', kill: KILL_SWITCH }));

// minimal crypto stub
app.get('/api/crypto/generate', (req,res)=> res.json({ address:'0x'+Date.now().toString(16).slice(-20), network:'demo-eth'}));

app.listen(PORT, ()=>console.log('Amplify L4 backend running on port '+PORT));
